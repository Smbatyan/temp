1. Install and run Docker
2. Open terminal and run command 'docker-compose up -d'
3. Run command 'docker ps' to get runed container id
4. Run command 'docker cp rabbitmq_delayed_message_exchange-4.0.2.ez [container_id]:/plugins'
5. Open runed container terminal in docker and execute command 'rabbitmq-plugins enable rabbitmq_delayed_message_exchange'
6. Go to localhost:15672 and signin to Rabbit manager (user = guest , pass = guest)
7. Go to Admin tab and add new user username = loan-origination-app, password = loan-origination-app, role = Admin
8. Click on new created user and set default permissions
9. Install DBT.EventBus.RabbitMQ.1.1.0.nupkg to visual studio